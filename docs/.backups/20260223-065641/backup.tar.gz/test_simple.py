import os
def foo( ):
    x=1+2
    return  x
