

import os
import sys


def test_function():
    return undefined_variable


def another_function():
    x = 1
    y = 2

    z = 3
    return x + y
