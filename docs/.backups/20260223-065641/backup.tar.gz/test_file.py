import os,sys
def foo( ):
    x=1+2
    return  x
class Bar: pass
